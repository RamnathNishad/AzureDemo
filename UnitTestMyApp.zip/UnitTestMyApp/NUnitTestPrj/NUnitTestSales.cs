﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using MyAppLib;

namespace NUnitTestPrj
{
    [TestFixture]
    public class NUnitTestSales
    {
        [Test]
        public void TestMethodGetSalesDiscount_GT0_LT1K()
        {
            Sales obj = new Sales();

            int salesAmount = 500;
            double expected = 400;
            double actual = obj.GetSalesDiscount(salesAmount);

            Assert.AreEqual(expected, actual);
        }
        [Test]
        public void TestMethodGetSalesDiscount_GE1000_LT2000()
        {
            Sales obj = new Sales();

            int salesAmount = 1500;
            double expected = 1300;
            double actual = obj.GetSalesDiscount(salesAmount);

            Assert.AreEqual(expected, actual);
        }
        [Test]
        public void TestMethodGetSalesDiscount_GE2000()
        {
            Sales obj = new Sales();

            int salesAmount = 5000;
            double expected = 4500;
            double actual = obj.GetSalesDiscount(salesAmount);

            Assert.AreEqual(expected, actual);
        }
        //[Test]
        //[(typeof(System.ArgumentException), "invalid sales amount, it must be >0")]
        //public void TestMethodGetSalesDiscount_Arg0_OR_LT0()
        //{
        //    Sales obj = new Sales();

        //    int salesAmount = 0;
        //    double actual = obj.GetSalesDiscount(salesAmount);
        //}
    }
}
