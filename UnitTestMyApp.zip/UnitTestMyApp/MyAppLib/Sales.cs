﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAppLib
{
    public class Sales
    {

        public double GetSalesDiscount(int salesAmount)
        {
            double discountedAmt = 0;
            if (salesAmount > 0 && salesAmount<1000)
            {
                discountedAmt = salesAmount - 100;
            }
            else if(salesAmount>=1000 && salesAmount<2000)
            {
                discountedAmt = salesAmount - 200;
            }
            else if (salesAmount >= 2000)
            {
                discountedAmt = salesAmount - 500;
            }
            else
            {
                throw new ArgumentException("invalid sales amount, it must be >0");
            }

            return discountedAmt;
        }

    }
}


class Account
{

    public int AccNo { get; set; }
    public string AccountType { get; set; }
    public string Name { get; set; }
    public string Branch { get; set; }

    public double RateOfInterest { get; set; }
    public void OpenAccount()
    {
        AccNo = 10002122;
        AccountType = "Savings";
        Name = "Raghu";
        Branch = "Bangalore";
        RateOfInterest = GetRateOfInterest();
    }

    public double GetRateOfInterest()
    {
        double roi =7.5;
        //get the rate of interest from database using DAL as 
        //it depends upon the rate of interest stored in table
        return roi;
    }
    public string DisplayAcDetails()
    {
        string info = "Account no:" + AccNo + "\n";
        info = "Type of Account:" + AccountType + "\n";
        info = "Customet Name:" + Name + "\n";
        info = "Branch:" + Branch + "\n";
        info = "Rate of interest:" + RateOfInterest + "\n";

        return info;
    }

}