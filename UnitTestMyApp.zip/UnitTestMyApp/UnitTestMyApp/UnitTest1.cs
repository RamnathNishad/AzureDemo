﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyAppLib;

namespace UnitTestMyApp
{
    [TestClass]
    public class UnitTestSales
    {
        //[TestMethod]
        //public void TestMethodGetSalesDiscount()
        //{
        //    Sales obj = new Sales();

        //    int salesAmount = 1500;
        //    double expected = 1300;
        //    double actual = obj.GetSalesDiscount(salesAmount);

        //    Assert.AreEqual(expected, actual);
        //}

        [TestMethod]
        public void TestMethodGetSalesDiscount_GT0_LT1000()
        {
            Sales obj = new Sales();

            int salesAmount = 500;
            double expected = 400;
            double actual = obj.GetSalesDiscount(salesAmount);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestMethodGetSalesDiscount_GE1000_LT2000()
        {
            Sales obj = new Sales();

            int salesAmount = 1500;
            double expected = 1300;
            double actual = obj.GetSalesDiscount(salesAmount);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestMethodGetSalesDiscount_GE2000()
        {
            Sales obj = new Sales();

            int salesAmount = 5000;
            double expected = 4500;
            double actual = obj.GetSalesDiscount(salesAmount);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        [ExpectedException(typeof(System.ArgumentException), "invalid sales amount, it must be >0")]
        public void TestMethodGetSalesDiscount_Arg0_OR_LT0()        
        {            
                Sales obj = new Sales();

                int salesAmount = 0;
                double actual = obj.GetSalesDiscount(salesAmount);           
        }
    }
}
